nohup uwsgi rest_api.ini --processes 5 &
